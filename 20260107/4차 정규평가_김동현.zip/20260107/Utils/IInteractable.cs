﻿

public interface IInteractable
{
    public void Interact(PlayerCharacter player);
}