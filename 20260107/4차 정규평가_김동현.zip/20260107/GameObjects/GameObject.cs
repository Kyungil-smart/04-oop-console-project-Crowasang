﻿

public abstract class GameObject
{
    public char Symbol { get; set; }
    public Vector Position{ get; set; }
}