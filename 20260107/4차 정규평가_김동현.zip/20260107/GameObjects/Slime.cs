﻿

public class Slime : Monster
{
    public Slime() : base(30)
    {
        Name = "Slime";
        Symbol = 'S';
        Damage = 10;
    }
}