﻿

public class Goblin : Monster
{
    public Goblin() : base(60)
    {
        Name = "Goblin";
        Symbol = 'G';
        Damage = 20;
    }
}